import "../index.css";

const Footer = () => {
  return (
    <footer className="footer">
      <p className="footer__stamp">© 2020 Mesto Russia</p>
    </footer>
  );
};

export default Footer;
