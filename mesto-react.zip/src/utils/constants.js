export const POPUP_OPENED = 'popup_status_opened';
export const BTTN_INACTIVE = 'form__button_status_inactive';
export const ERR_ACTIVE = 'form__input-error_active';
export const EMTY_CARD = {link: '', name: ''};
export const API_URL = 'https://mesto.nomoreparties.co/v1/cohort-38/';
export const ACCESS_KEY = '1478eacc-254a-456a-9432-9f80e3ac7fe8';